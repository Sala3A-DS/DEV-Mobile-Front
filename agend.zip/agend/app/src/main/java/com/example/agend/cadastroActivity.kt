package com.example.agend

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CadastroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        val editNome = findViewById<EditText>(R.id.editNome)
        val editEmail = findViewById<EditText>(R.id.editEmailCadastro)
        val editSenha = findViewById<EditText>(R.id.editSenhaCadastro)
        val botaoCadastrar = findViewById<Button>(R.id.botaoCadastrar)
        val textoVoltarLogin = findViewById<TextView>(R.id.textoVoltarLogin)
        val radioGrupo = findViewById<RadioGroup>(R.id.radioGrupoPerfil)

        botaoCadastrar.setOnClickListener {
            val nome = editNome.text.toString().trim()
            val email = editEmail.text.toString().trim()
            val senha = editSenha.text.toString().trim()
            val perfilId = radioGrupo.checkedRadioButtonId

            if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "⚠️ Preencha todos os campos!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (perfilId == -1) {
                Toast.makeText(this, "⚠️ Selecione seu perfil!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val perfil = when (perfilId) {
                R.id.radioProfessor -> "Professor"
                R.id.radioDiretor -> "Diretor"
                else -> ""
            }

            val prefs = getSharedPreferences("usuarios", MODE_PRIVATE)
            prefs.edit()
                .putString(email, senha)
                .putString("nome_$email", nome)
                .putString("perfil_$email", perfil)
                .apply()

            Toast.makeText(this, "✅ Cadastrado com sucesso!", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        textoVoltarLogin.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}