package com.example.agend

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class AgendamentoActivity : AppCompatActivity() {

    private var dataSelecionada = ""
    private var horarioSelecionado = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agendamento)

        val editSala = findViewById<EditText>(R.id.editSala)
        val botaoData = findViewById<Button>(R.id.botaoData)
        val textoData = findViewById<TextView>(R.id.textoDataSelecionada)
        val botaoHorario = findViewById<Button>(R.id.botaoHorario)
        val textoHorario = findViewById<TextView>(R.id.textoHorarioSelecionado)
        val botaoAgendar = findViewById<Button>(R.id.botaoAgendar)

        botaoData.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, ano, mes, dia ->
                    dataSelecionada = "$dia/${mes + 1}/$ano"
                    textoData.text = "📅 Data: $dataSelecionada"
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        botaoHorario.setOnClickListener {
            val calendar = Calendar.getInstance()
            TimePickerDialog(
                this,
                { _, hora, minuto ->
                    horarioSelecionado = String.format("%02d:%02d", hora, minuto)
                    textoHorario.text = "⏰ Horário: $horarioSelecionado"
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
            ).show()
        }

        botaoAgendar.setOnClickListener {
            val sala = editSala.text.toString().trim()

            if (sala.isEmpty()) {
                Toast.makeText(this, "⚠️ Digite o nome da sala!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (dataSelecionada.isEmpty()) {
                Toast.makeText(this, "⚠️ Selecione uma data!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (horarioSelecionado.isEmpty()) {
                Toast.makeText(this, "⚠️ Selecione um horário!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            HomeActivity.listaAgendamentos.add(
                "🏫 $sala | 📅 $dataSelecionada | ⏰ $horarioSelecionado"
            )

            Toast.makeText(this, "✅ Agendamento realizado com sucesso!", Toast.LENGTH_LONG).show()
            setResult(RESULT_OK)
            finish()
        }
    }
}