package com.example.agend

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val editEmail = findViewById<EditText>(R.id.editEmail)
        val editSenha = findViewById<EditText>(R.id.editSenha)
        val botaoEntrar = findViewById<Button>(R.id.botaoEntrar)
        val textoCadastro = findViewById<TextView>(R.id.textoCadastro)
        val textoErro = findViewById<TextView>(R.id.textoErroLogin)
        val textoEsqueci = findViewById<TextView>(R.id.textoEsqueciSenha)

        botaoEntrar.setOnClickListener {
            val email = editEmail.text.toString().trim()
            val senha = editSenha.text.toString().trim()
            textoErro.visibility = View.GONE

            if (email.isEmpty() && senha.isEmpty()) {
                textoErro.text = "⚠️ Preencha o email e a senha!"
                textoErro.visibility = View.VISIBLE
                return@setOnClickListener
            }
            if (email.isEmpty()) {
                textoErro.text = "⚠️ Digite seu email!"
                textoErro.visibility = View.VISIBLE
                return@setOnClickListener
            }
            if (senha.isEmpty()) {
                textoErro.text = "⚠️ Digite sua senha!"
                textoErro.visibility = View.VISIBLE
                return@setOnClickListener
            }

            val prefs = getSharedPreferences("usuarios", MODE_PRIVATE)
            val senhaSalva = prefs.getString(email, null)

            if (senhaSalva == null) {
                textoErro.text = "⚠️ Email não cadastrado!"
                textoErro.visibility = View.VISIBLE
                return@setOnClickListener
            }
            if (senhaSalva != senha) {
                textoErro.text = "⚠️ Senha incorreta!"
                textoErro.visibility = View.VISIBLE
                return@setOnClickListener
            }

            val intent = Intent(this, HomeActivity::class.java)
            intent.putExtra("email", email)
            startActivity(intent)
            finish()
        }

        textoCadastro.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
            finish()
        }

        textoEsqueci.setOnClickListener {
            startActivity(Intent(this, EsqueciSenhaActivity::class.java))
        }
    }
}